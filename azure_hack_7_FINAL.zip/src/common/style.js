export default {
  primary: "#083d77",
  primaryText: "white",
  secondary: "#e53d00",
  secondaryText: "white",
  greyLight: "rgba(1,1,1,0.2)",
  greyMid: "rgba(1,1,1,0.5)",
  greyDark: "rgba(1,1,1,0.7)",
};
