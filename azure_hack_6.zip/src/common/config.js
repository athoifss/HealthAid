export default {
  baseUrl: "http://52.172.158.219:8000/api",
  apiToken: "4ygdf5gthhyxx#45",
};
